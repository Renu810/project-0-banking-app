package com.revature.bms.dao;

import com.revature.bms.model.User;

public interface UserDAO {
	public boolean validateUser(User user);

}
