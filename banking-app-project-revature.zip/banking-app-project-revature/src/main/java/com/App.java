package com;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	BankingApp bankingapp = new BankingApp();
    	bankingapp.startBankingApp();
    }
}
